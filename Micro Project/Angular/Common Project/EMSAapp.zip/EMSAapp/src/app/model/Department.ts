export class Department {
    deptId: number = 0;
    deptName: String = "";
}